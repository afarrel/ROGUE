#################
################ Reference FILES ##########
###########################################
library(pheatmap)
#Human_GO = read.table("~/Documents/Gene_Ontologies/Homo_Sapien/goa_humanT.gaf",skip=34,header = F,sep="\t")
Human_GO = readLines("~/Documents/Gene_Ontologies/Homo_Sapien/goa_humanT.gaf")
GO_defs  = readLines("~/Documents/Gene_Ontologies/Homo_Sapien/go.obo")



length(Human_GO)
which(as.character(Human_GO[,3]) == "HDGFRP3")

Target.GO.Lines = Human_GO[grep("LDHA",Human_GO)]
Target.GO.table = c()
for(i in 1:length(Target.GO.Lines))
{
  temp.line = unlist(strsplit(Target.GO.Lines[i],split="\t"))
  Target.GO.table = rbind(Target.GO.table,temp.line)
}

unique(unlist(Target.GO.table[which(Target.GO.table[,3]=="LDHA"),5]))



GO_defs.subset = subset(GO_defs,(substr(GO_defs,1,4)=="name" | substr(GO_defs,1,4)=="is_a" | substr(GO_defs,1,3)=="id:" | substr(GO_defs,1,1)==""))
GO_defs.subset = subset(GO_defs,(substr(GO_defs,1,1)!="s" & substr(GO_defs,1,1)!="d" & substr(GO_defs,1,1)!="c" & substr(GO_defs,1,1)!="r" & substr(GO_defs,1,1)!="f" & substr(GO_defs,1,1)!="x" & substr(GO_defs,1,1)!="a" & substr(GO_defs,1,1)!="p" & substr(GO_defs,1,1)!="t" & substr(GO_defs,1,1)!="[" )) 
Human_GO.subset = subset(Human_GO,(grepl("EXP",Human_GO) | grepl("IDA",Human_GO) | grepl("IPI",Human_GO) | grepl("IMP",Human_GO) | grepl("IGI",Human_GO) | grepl("IEP",Human_GO) | grepl("TAS",Human_GO)))


#####################################
GO.IDs = substr(GO_defs.subset[which(substr(GO_defs.subset,1,3)=="id:")],5,14)
GO.Names = substr(GO_defs.subset[which(substr(GO_defs.subset,1,3)=="id:")+1],7,nchar(GO_defs.subset[which(substr(GO_defs.subset,1,3)=="id:")+1]))
GO.info = cbind(GO.IDs,GO.Names)
GO.info.count = data.frame(cbind(GO.info,0))

#GO.info[1:5,]


Target.GO.Lines = Human_GO[grep("LDHA",Human_GO)]
Target.GO.table = c()
for(i in 1:length(Target.GO.Lines))
{
  temp.line = unlist(strsplit(Target.GO.Lines[i],split="\t"))
  Target.GO.table = rbind(Target.GO.table,temp.line)
}

Target.GO.ID.List = unique(unlist(Target.GO.table[which(Target.GO.table[,3]=="LDHA"),5]))

GO.info[which(GO.info[,1] %in% Target.GO.ID.List),]


GO.info.count[1:3,]


GO.hierarchy = read.table("~/Documents/Gene_Ontologies/Homo_Sapien/go.hierarchy.txt",sep="\t",skipNul = T)
#?read.table

GO.hierarchy = readLines("~/Documents/Gene_Ontologies/Homo_Sapien/go.hierarchy.txt")

GO.Hierarchy.Heads = c()
#GO.hierarchy.List
for(i in 1:length(GO.hierarchy))
{
  temp.list = unlist(strsplit(GO.hierarchy[i],split="\t"))
  GO.Hierarchy.Heads = c(GO.Hierarchy.Heads,temp.list[1])
  
  if(i == 1)
  {
    GO.hierarchy.List = list(temp.list)
  }
  if(i > 1)
  {
    GO.hierarchy.List = c(GO.hierarchy.List,list(temp.list))
  }
  
}




list.GO = "Biological Process"
GO.sub.list = c()
GO.inx = which(GO.Hierarchy.Heads %in% list.GO)
GO.List.Check = F
while(GO.List.Check == F)
{
  Start.GO.inx = length(GO.inx)
  for(i in 1:length(GO.inx))
  {
     GO.hierarchy.List[[GO.inx[i]]]
     GO.sub.list = c(GO.sub.list,GO.hierarchy.List[[GO.inx[i]]])
  }
  GO.sub.list = unique(GO.sub.list)
  GO.inx = which(GO.Hierarchy.Heads %in% GO.sub.list)
  End.GO.inx = length(GO.inx)

  if(Start.GO.inx == End.GO.inx){GO.List.Check = T}
}


"primary metabolic process"


#################
################ Functions ################
###########################################

Get_GO_List = function(GO_ID)
{
  inxS = grep(paste("id:",GO_ID),GO_defs.subset)
  inxE=inxS
  while(nchar(GO_defs.subset[inxE])>2)
  {
    inxE=inxE+1
  }
  New_GO_IDs = substr(GO_defs.subset[inxS:inxE][grep("is_a:",GO_defs.subset[inxS:inxE])],7,16)
  
  return(New_GO_IDs)
}

Get_GO_List("GO:0006639")
####################################


Get_Ont_List = function(Gene_Sym)
{
  GO.subset = c()
  Gene_Sym.set = subset(Human_GO.subset,grepl(paste("\t",Gene_Sym,"\t",sep=""),Human_GO.subset))
  for(i in 1:length(Gene_Sym.set))
  {
    GO.subset = rbind(GO.subset,unlist(strsplit(Gene_Sym.set[i],"\t")))
  }                  
  
  
  GO_ID_List = GO.subset[GO.subset[,9]=="P",5]
  #while(length(Get_GO_List(New_ID)) >0 )
  j=1
  #for(j in 1:length(GO_ID_List))
  while(j<=length(GO_ID_List))
  {
    #GO_ID_List[P]
    GO_ID_List = unique(c(GO_ID_List,Get_GO_List(GO_ID_List[j])))
    #New_ID = Get_GO_List(as.character(New_ID))
    j=j+1
  }
  
  Ont_List = unique(GO_ID_List[length(GO_ID_List):1])
  unique(GO_ID_List)
  
  Ont_def_List = c()
  for(i in 1:length(Ont_List))
  {
    inx1 = which( GO_defs.subset %in% paste("id:",Ont_List[i]))
    Ont_def_List[i] = paste(GO_defs.subset[inx1],GO_defs.subset[inx1+2],GO_defs.subset[inx1+1],sep=" | ")
  }
  
  return(Ont_def_List)
}

####################################


Get_GO_Level = function(GO_ID) 
{
  New_ID = GO_ID
  J=0
  while(length(New_ID)>0)
  {
    #GO_ID_List[P]
    New_ID = Get_GO_List(New_ID[1])
    J=J+1
  }
  return(J)
}
############## End Functions ##############
###########################################
###########################################





Get_GO_info_plots = function(GeneList_names)
{
 
  #as.matrix(rbind(c(2,3,4),c(3,4,6)))
   
  
  comb.list = c()
  GO.Lists = c()
  for(k in 1:length(GeneList_names))
  {
    #L.pts[k,1] = 0
    Gene_Sym = GeneList_names[k]
    List.GS = Get_Ont_List(Gene_Sym)
    GO.Lists = c(GO.Lists,list(List.GS))
    comb.list = union(comb.list,List.GS)
    #L.pts[k] = sum(L.pts.matrix[k,])
  }

  L.pts.matrix = matrix(ncol=length(GeneList_names),nrow=length(comb.list),0)
  L.pts=c()
  for(k in 1:length(comb.list))
  {
    for(l in 1:length(GeneList_names))
    {
      L.pts.matrix[k,l] = length(which(unlist(GO.Lists[l])==comb.list[k]))
    }
    L.pts[k] = sum(L.pts.matrix[k,])
  }
 
  
  #library(pheatmap)
  rownames(L.pts.matrix) = substr(comb.list,1,14)
  colnames(L.pts.matrix) = GeneList_names
  #pheatmap(L.pts.matrix,annotation_names_col=T)
  #PT = pheatmap(L.pts.matrix[which(L.pts>1),],annotation_names_col=T,annotation_names_row=T)
  #PT = pheatmap(t(L.pts.matrix[which(L.pts>1),]),annotation_names_col=T,annotation_names_row=T)
  
  #comb.list[which(L.pts>1)]
  #comb.list[which(L.pts>1)][PT$tree_row$order]
  
  
  #comb.list[which(L.pts>1)][PT$tree_row$order]
  
  
  
  L.pts.matrix.short.comp = matrix(nrow=nrow(L.pts.matrix.short),ncol=nrow(L.pts.matrix.short))
  #L.pts.matrix.short.comp
  
  colnames(L.pts.matrix.short.comp) = rownames(L.pts.matrix.short)
  rownames(L.pts.matrix.short.comp) = rownames(L.pts.matrix.short)
  
  for(x in 1:nrow(L.pts.matrix.short.comp))
  {
    for(y in 1:nrow(L.pts.matrix.short.comp))
    {
      L.pts.matrix.short.comp[x,y] = sum(L.pts.matrix.short[y,L.pts.matrix.short[x,]>0])/sum(L.pts.matrix.short[x,L.pts.matrix.short[x,]>0])
    }
  }
  
  GO_Levels = c()
  for(x in 1:nrow(L.pts.matrix.short))
  {
    GO_id = rownames(L.pts.matrix.short)[x]
    GO_Levels[x] = Get_GO_Level(substr(GO_id,5,nchar(GO_id)))
  }
  
  
  #cbind(
  #GO_Levels[PTMtx$tree_row$order],
  #rownames(L.pts.matrix.short)[PTMtx$tree_row$order]
  #)
    #PTMtx = pheatmap(L.pts.matrix.short.comp,annotation_names_col=T,annotation_names_row=T,annotation_colors = tl1)
  
    tl1 = list( col_array[PTMtx$tree_col$order])
  #image(seq_along(values), 1, as.matrix(seq_along(values)), col = colors, axes = F)
    
  col_array=c();for(x in 1:length(GO_Levels)){col_array[x]=colors[GO_Levels[x]]}
  #image(seq_along(GO_Levels[PTMtx$tree_col$order]), 1, as.matrix(seq_along(GO_Levels)), col = col_array[PTMtx$tree_col$order],axes = F)
  
  
  #PT$tree_row$order
  
  values = c(min(GO_Levels):max(GO_Levels))
  rr <- range(values)
  svals <- (values-rr[1])/diff(rr)
  f <- colorRamp(c("Blue", "Red"))
  colors <- rgb(f(svals)/255)
  
  
  X = colors
  names(X) = c(min(GO_Levels):max(GO_Levels))
  
  T_GO_col = data.frame(
    Levels = factor(GO_Levels)
  )
  rownames(T_GO_col) = rownames(L.pts.matrix.short.comp)
  
  T_GO_colors=list(
    Levels=X
  )
  PTMtx = pheatmap(L.pts.matrix.short.comp,annotation_names_col=T,annotation_names_row=T,annotation_col = T_GO_col,annotation_colors = T_GO_colors,annotation_row = T_GO_col)
  
  if(max(L.pts.matrix[which(L.pts>1),])!=min(L.pts.matrix[which(L.pts>1),]))
  {
    PT = pheatmap(L.pts.matrix[which(L.pts>1),],annotation_names_col=T,annotation_names_row=T,annotation_colors = T_GO_colors,annotation_row = T_GO_col)
  }
  if(max(L.pts.matrix[which(L.pts>1),])==min(L.pts.matrix[which(L.pts>1),]))
  {
    PT = pheatmap(L.pts.matrix,annotation_names_col=T,annotation_names_row=T,annotation_colors = T_GO_colors)
  }
  
} #Get_GO_info_plots = function(comb.list)
#comb.list[which(L.pts>1)][19]


Human_GO = read.table("~/Documents/Gene_Ontologies/Homo_Sapien/goa_humanT.gaf",skip=34,header = F,sep="\t")
unique.human.GO = (unique(Human_GO[,5]))

for(i in 9174:length(unique.human.GO))
{
  GO_ID_List=c(as.character(unique.human.GO[i]))
  j=1
  while(j<=length(GO_ID_List))
  {
    #GO_ID_List[P]
    GO_ID_List = unique(c(GO_ID_List,Get_GO_List(GO_ID_List[j])))
    #New_ID = Get_GO_List(as.character(New_ID))
    j=j+1
  }
  write(paste(GO_ID_List,collapse=" "),"~/Documents/Gene_Ontologies/Homo_Sapien/Grouped.GO.txt",append = T)
}






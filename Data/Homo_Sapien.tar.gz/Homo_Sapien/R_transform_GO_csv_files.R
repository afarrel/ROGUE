
Ontology.folder = "/Users/farrelal/Documents/Gene_Ontologies/Homo_Sapien/"

Human_GO.Orig = readLines(paste(Ontology.folder,"goa_human.gaf",sep=""))
Mouse_GO.Orig = readLines(paste(Ontology.folder,"gene_association.mgi",sep=""))

Human.Header.Lines.Count = length(which(substr(Human_GO.Orig,1,1)=="!"))
Mouse.Header.Lines.Count = length(which(substr(Mouse_GO.Orig,1,1)=="!"))

write(Human_GO.Orig[-c(1:Human.Header.Lines.Count)],file = paste(Ontology.folder,"goa_humanT.gaf",sep=""))
write(Mouse_GO.Orig[-c(1:Mouse.Header.Lines.Count)],file = paste(Ontology.folder,"gene_associationT.mgi",sep=""))

Human_GO = read.table(paste(Ontology.folder,"Test5.txt",sep=""),sep="\t",header = F)
Mouse_GO = read.table(paste(Ontology.folder,"Test6.txt",sep=""),sep="\t",header = F)

#write.table(Human_GO[,c(3,5,7,9,13)],paste(Ontology.folder,"Test5.csv",sep=""),row.names = F,col.names=F,quote = F,sep=",")

Start.Line = Header.Lines.Count+1
for(i in Start.Line:length(Human_GO.Orig))
{
  Human_CSV_file_Line = paste(unlist(strsplit(Human_GO.Orig[i],split = "\t"))[c(3,5,7,9,13)],collapse=",")
  
  if(i==Start.Line) {write(Human_CSV_file_Line,paste(Ontology.folder,"goa_humanT_sel2.csv",sep=""))}
  if(i>Start.Line) {write(Human_CSV_file_Line,paste(Ontology.folder,"goa_humanT_sel2.csv",sep=""),append = T)}
}

Start.Line = Mouse.Header.Lines.Count+1
for(i in Start.Line:length(Mouse_GO.Orig))
{
  Mouse_CSV_file_Line = paste(unlist(strsplit(Mouse_GO.Orig[i],split = "\t"))[c(3,5,7,9,13)],collapse=",")
  
  if(i==Start.Line) {write(Mouse_CSV_file_Line,paste(Ontology.folder,"gene_associationT_sel2.csv",sep=""))}
  if(i>Start.Line) {write(Mouse_CSV_file_Line,paste(Ontology.folder,"gene_associationT_sel2.csv",sep=""),append = T)}
}

#############
############# Get GO Defs
#############


GO_defs  = readLines("~/Documents/Gene_Ontologies/Homo_Sapien/go.obo")


GO_defs.subset = subset(GO_defs,(substr(GO_defs,1,1)!="s" & substr(GO_defs,1,1)!="d" & substr(GO_defs,1,1)!="c" & substr(GO_defs,1,1)!="r" & substr(GO_defs,1,1)!="f" & substr(GO_defs,1,1)!="x" & substr(GO_defs,1,1)!="a" & substr(GO_defs,1,1)!="p" & substr(GO_defs,1,1)!="t" & substr(GO_defs,1,1)!="[" )) 



GO.Name.Table = cbind(substr(GO_defs[(which(substr(GO_defs,1,6)=="name: ")-1)],5,14),
                      substr(GO_defs[which(substr(GO_defs,1,6)=="name: ")],7,nchar(GO_defs[which(substr(GO_defs,1,6)=="name: ")])))

write.table(GO.Name.Table,"~/Documents/Gene_Ontologies/Homo_Sapien/Go.Name.Table.txt",row.names = F, col.names = F,sep = "\t",quote = F)













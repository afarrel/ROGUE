library(pheatmap)
Human_GO = readLines("~/Documents/Gene_Ontologies/Homo_Sapien/goa_humanT.gaf")
GO_defs  = readLines("~/Documents/Gene_Ontologies/Homo_Sapien/go.obo")

#Generate go.hierarchy2.txt #
GO.groups = unique(substr(GO_defs[substr(GO_defs,1,9) == "is_a: GO:"],7,16))
for(l in 1:length(GO.groups))
{
  GO.groupMemb.inx = which(substr(GO_defs,1,16) == paste("is_a:",GO.groups[l]))
  GO.Group_Set = c(GO.groups[l])
  for(k in 1:length(GO.groupMemb.inx))
  {
    inx.point = GO.groupMemb.inx[k] 
    while(substr(GO_defs[inx.point],1,7) != "id: GO:")
    {
      inx.point = inx.point-1
    }
    
    GO.Group_Set = c(GO.Group_Set,substr(GO_defs[inx.point],5,17))
  }
  if(l == 1) {write.table(rbind(GO.Group_Set),file="~/Documents/Gene_Ontologies/Homo_Sapien/go.hierarchy2.txt",col.names = F,row.names = F, quote = F,append = F)}
  if(l > 1) {write.table(rbind(GO.Group_Set),file="~/Documents/Gene_Ontologies/Homo_Sapien/go.hierarchy2.txt",col.names = F,row.names = F, quote = F,append = T)}
}#for(l in 1:length(GO.groups))

GO.hierarchy = readLines("~/Documents/Gene_Ontologies/Homo_Sapien/go.hierarchy2.txt")


#Test.Gene.List = c("LDHA","GLA")

##########
##########STEP
##########

GO.IDs = substr(GO_defs[which(substr(GO_defs,1,3)=="id:")],5,14)
GO.Names = substr(GO_defs[which(substr(GO_defs,1,3)=="id:")+1],7,nchar(GO_defs[which(substr(GO_defs,1,3)=="id:")+1]))
GO.info = data.frame(GO.IDs,GO.Names)
GO.info.count = GO.info



##########
##########STEP
##########

for(i in 1:length(Test.Gene.List))
{

  Target.GO.Lines = Human_GO[grep(Test.Gene.List[i],Human_GO)]
  Target.GO.table = c()
  for(j in 1:length(Target.GO.Lines))
  {
    temp.line = unlist(strsplit(Target.GO.Lines[j],split="\t"))
    Target.GO.table = rbind(Target.GO.table,temp.line)
  } #for(j in 1:length(Target.GO.Lines))
  if(ncol(Target.GO.table)>1)
  {
    Target.GO.IDs = unique(unlist(Target.GO.table[which(Target.GO.table[,3]=="LDHA"),5]))
    GO.info.count = data.frame(cbind(GO.info.count,0))
    colnames(GO.info.count)[ncol(GO.info.count)] = Test.Gene.List[i]
  } #if(ncol(Target.GO.table)>1)
} #for(i in 1:length(Test.Gene.List))

##########
##########STEP
##########


if(ncol(GO.info.count)>2)
{
  for(i in 3:ncol(GO.info.count))
  {
    
    Target.GO.Lines = Human_GO[grep(colnames(GO.info.count)[i],Human_GO)]
    Target.GO.table = c()
    for(j in 1:length(Target.GO.Lines))
    {
      temp.line = unlist(strsplit(Target.GO.Lines[j],split="\t"))
      Target.GO.table = rbind(Target.GO.table,temp.line)
    } #for(j in 1:length(Target.GO.Lines))
    
    Target.GO.ID.List = unique(unlist(Target.GO.table[which(Target.GO.table[,3]==colnames(GO.info.count)[i]),5]))
    GO.info.count[which(as.character(GO.info.count$GO.IDs) %in% Target.GO.ID.List),i] = 1
  } #for(i in 3:ncol(GO.info.count))
} #if(ncol(GO.info.count)>2)



##########
##########STEP
##########

GO.Hierarchy.Heads = c()
for(i in 1:length(GO.hierarchy))
{
  temp.list = unlist(strsplit(GO.hierarchy[i],split=" "))
  GO.Hierarchy.Heads = c(GO.Hierarchy.Heads,temp.list[1])
  
  if(i == 1)
  {
    GO.hierarchy.List = list(temp.list)
  }
  if(i > 1)
  {
    GO.hierarchy.List = c(GO.hierarchy.List,list(temp.list))
  }
}



##########
##########STEP
##########

Get_GO_subList = function(GO_NAME)
  {
  list.GO = as.character(GO.info.count$GO.IDs[which(GO.info.count$GO.Names == GO_NAME)])
  
  #list.GO = "GO:0008152"
  if(length(list.GO)>0)
  {
    GO.sub.list = c()
    GO.inx = which(GO.Hierarchy.Heads %in% list.GO)
    GO.List.Check = F
    while(GO.List.Check == F)
    {
      Start.GO.inx = length(GO.inx)
      for(i in 1:length(GO.inx))
      {
        GO.hierarchy.List[[GO.inx[i]]]
        GO.sub.list = c(GO.sub.list,GO.hierarchy.List[[GO.inx[i]]])
      }
      GO.sub.list = unique(GO.sub.list)
      GO.inx = which(GO.Hierarchy.Heads %in% GO.sub.list)
      End.GO.inx = length(GO.inx)
      
      if(Start.GO.inx == End.GO.inx){GO.List.Check = T}
    }
    
    return(GO.sub.list)
  }#if(length(list.GO)>0)
}#Get_GO_subList = function(GO_NAME)
##########
##########STEP
##########
#GO_Top_Level = c("molecular_function","biological_process","cellular_component")

#GO.count.table = data.frame(GO_Top_Level,0)
#for(i in 1:length(GO_Top_Level))
#{
#  
#  #length(as.character(GO.info.count$GO.IDs[which(GO.info.count$GO.Names == GO_Top_Level[i])]))
#  GO.sub.list = Get_GO_subList(GO_Top_Level[i])
#  GO.info.count.Subset = GO.info.count[which(GO.info.count$GO.IDs %in% GO.sub.list),]
#  
#  if(ncol(GO.info.count.Subset)==3){ Total_genes = max(GO.info.count.Subset[,3]) }
#  if(ncol(GO.info.count.Subset)>3){ Total_genes = sum(apply(GO.info.count.Subset[,-1:-2], 2, function(x) max(x, na.rm = TRUE))) }
#  if(ncol(GO.info.count.Subset)<3){ Total_genes = 0}
#  GO.count.table[i,2] = as.numeric(Total_genes)
#  
#}#for(i in 1:length(GO_Top_Level))






GO.Hierarchy.Heads.names = as.character(GO.info$GO.Names[match(GO.Hierarchy.Heads,GO.info$GO.IDs)])
for(i in 1:length(GO.Hierarchy.Heads))
{
	#GO.Hierarchy.Heads
	GO.sub.list = Get_GO_subList(GO.Hierarchy.Heads.names[i])
	 if(i == 1) {write.table(rbind(GO.sub.list),file="~/Documents/Gene_Ontologies/Homo_Sapien/go.Ext.hierarchy3.txt",col.names = F,row.names = F, quote = F,append = F)}
         if(i > 1) {write.table(rbind(GO.sub.list),file="~/Documents/Gene_Ontologies/Homo_Sapien/go.Ext.hierarchy3.txt",col.names = F,row.names = F, quote = F,append = T)}
}
